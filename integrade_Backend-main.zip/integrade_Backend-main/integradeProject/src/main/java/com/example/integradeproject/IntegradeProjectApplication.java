package com.example.integradeproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegradeProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(IntegradeProjectApplication.class, args);
    }

}
